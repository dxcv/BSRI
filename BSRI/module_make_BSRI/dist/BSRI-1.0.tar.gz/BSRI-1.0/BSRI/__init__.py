__all__ = ['getdata', 'rundaily']
from BSRI import getdata, rundaily